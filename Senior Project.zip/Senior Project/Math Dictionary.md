## Sigma Notation
Sigma notation or summation notation is a way of representing the sum of values in a series. 
$$\sum^{n}_{i=1}{x_i}=x_1+x_2+x_3+...+x_n $$
In the above example: $\Sigma$ is used to show that it is a summation, $i$ is the index of summation, i=1 means that the summation starts at 1, and n is the upper limit of the summation or when the summation stops.
### source
[25]

## Convolution
Convolution is a way of combining 2 functions or sets of numbers in a way that is useful in image processing and in probability. The definition of convolution is:
$$(f*g)(t):=\int^{\infty}_{-\infty}f(x)\cdot g(t-x)dx$$
This way of expressing convolution is confusing so I recommend watching the video linked below.
https://www.youtube.com/watch?v=KuXjwB4LzSA
### source
[5]

## Derivatives
The derivative of a function usually denoted as $f'(x)$ or $\frac{dy}{dx}$ is the slope of it's function at a given point. Say you have a linear function $$y = mx+b$$
The derivative of that function will be $m$ at all points. With more complex functions like polynomials, you will end up with derivatives that have a dependent variable. For example $$\frac{d}{dx}(x^2) = 2x$$

## Partial Derivatives
#TODO Say you have a function with 2 variables in it $x$ and $y$ $$f(x,y) = x^2+y^3+2xy$$
You can take the partial derivatives of this function by taking the derivative of the function with respect to one variable and treating the rest as constants. In this instance if you were to take the derivative with respect to $x$ it would be $$\frac{\partial f}{\partial x}=2x+2y$$

