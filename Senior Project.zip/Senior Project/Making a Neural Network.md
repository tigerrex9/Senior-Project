If you are interested in getting started with making neural networks, I would recommend starting by getting comfortable with Python as it is the most popular language for making neural networks. Once you feel you have the hang of things, you can try a basic machine learning project. One of the most common projects is handwritten digit recognition, where you try to make a neural network that can accurately sort images of numbers written by different people into categories based on what the number was supposed to be. MNIST is a dataset that contains a total of 70,000 images of hand-written digits and is used frequently. MNIST is included with keras (the library that we are using to make the neural networks) so you can download it in your import statement.

```
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

from keras.datasets import mnist
from tensorflow.keras.callbacks import ModelCheckpoint
```

Now we set up the data parameters.
```
num_classes = 10
input_shape = (28, 28)
```

You can then load the dataset into the training and testing variables and scale them so that the pixels are between 0 and 1 instead of 0 and 255.
```
(x_train, y_train), (x_test, y_test) = mnist.load_data()

x_train = x_train.astype("float32") / 255
x_test = x_test.astype("float32") / 255
```
then we expand the dimensions of the inputs so when we add 2D layers we don't get errors.
```
x_train = np.expand_dims(x_train, -1)
x_test = np.expand_dims(x_test, -1)

```
And you have to convert the labels to "binary class matrices" which means that you give them a number.
```
y_train = keras.utils.to_categorical(y_train, num_classes)
y_test = keras.utils.to_categorical(y_test, num_classes)
```

## Making the Model
Now it's time to make the model itself. In Keras there are a million and one ways to make a model, but were going to stick with the way that it is done in the Keras API example for the MNIST dataset here: https://keras.io/examples/vision/mnist_convnet/ [20].  I leave selecting the [[Types of Layers|layers]] of the model as an exercise for the reader.
```
model = keras.Sequential(
    [
        #layers go here
        
    ]
)
model.summary()
```

## Training the Model
We made the model and now we have to train it. For more details on what we are actually doing when we train a model check out: [[Neural Network (NN)#How does math learn?|How Does Math Learn?]] First we have to set the batch size (the number of samples before the model is updated) and epochs (the number of whole passes through the dataset before the model is done training). Since computers like powers of 2 when storing things in memory, we will set the batch size to 128. We are only going to train for 5 epochs for now because training models takes a long time and we aren't very confident that our first model is very good. 
```
batch_size = 128
epochs = 15
```

Now we compile the model. This takes all of our layers and sets them up in a way that can be trained. Fit then takes the compiled model and uses [[Neural Network (NN)#The Gradient|gradient descent]] to make the model more accurate. Since doing gradient descent on a whole bunch of data at once is really slow, the computer will use the batch size to decide how many samples it looks at before back propagating.
In my case, I enabled the use of "checkpoints" where you saved models trained for different periods of time to compare them later on.
```
model.compile(
optimizer= keras.optimizers.Adam(1e-3),
loss="categorical_crossentropy",
metrics=["accuracy"],
)

model_history = model.fit(
x_train, y_train,
batch_size=batch_size,
epochs=epochs,
validation_split=0.1,
callbacks= checkpoint,
)
```

## Model Evaluation
Now it's time for the fun part: evaluating how well your model did.
```
score = model.evaluate(x_test, y_test, verbose=0)
print("Test loss:", score[0])
print("Test accuracy:", score[1])
```
If your model didn't do very well, don't sweat it, you can always change the layers of your model and the hyper parameters (stuff like batch size, epochs, dropout rate, etc) and retrain.

As a challenge, try making a model that passes 95% accuracy.
too easy? Try 99% accuracy.

If you want some more accurate data, you can use history plots and a confusion matrix. The history plot shows the metrics of the model over the history of training and a confusion matrix shows the model's guesses in comparison to the correct answers in a way that lets you analyze the places where the model was confused.

first make functions that plot the graphs. (Or steal mine.)
~~~
def plot_confusion_matrix(y_true, y_pred, class_names, normalize=None,
		title='Confusion Matrix', plot_numbers=False, display_names=None,
		figsize=(15, 11)):
		
	cm = confusion_matrix(y_true, y_pred, labels=class_names, normalize=normalize)
	
	if not display_names:
		display_names = class_names
	df_cm = pd.DataFrame(cm, index=display_names, columns=display_names)
	fig = plt.figure(figsize=figsize)
	sns.heatmap(df_cm, annot=plot_numbers, cmap='Blues', fmt='g')
	plt.setp(plt.gca().get_xticklabels(), ha="right", rotation=45)
	plt.ylabel('True Label')
	plt.xlabel('Predicted Label')
	plt.title(title)
	#return fig

def plot_graphs(history, best):

	plt.figure(figsize=[10,4])
	# summarize history for accuracy
	plt.subplot(121)
	plt.plot(history.history['accuracy'])
	plt.plot(history.history['val_accuracy'])
	plt.title('model accuracy across training\n best accuracy of %.02f'%best[1])
	plt.ylabel('accuracy')
	plt.xlabel('epoch')
	plt.legend(['train', 'test'], loc='upper left')
	# summarize history for loss
	plt.subplot(122)
	plt.plot(history.history['loss'])
	plt.plot(history.history['val_loss'])
	plt.title('model loss across training\n best loss of %.02f'%best[0])
	plt.ylabel('loss')
	plt.xlabel('epoch')
	plt.legend(['train', 'test'], loc='upper left')
	plt.show()\
~~~
#TODO I stole this, but i don't know who to credit.

This prints the history graphs of loss and accuracy.
~~~
model_performance = model.evaluate(x_test, y_test, batch_size=32)

plot_graphs(model_history, model_performance)
~~~

To plot the confusion matrix you first have to reshape the output matrix of the results of the predictions.
~~~
y_test_class = np.argmax(y_test, axis = 1)

y_pred = model.predict(x_test)
y_pred_class = np.argmax(y_pred, axis = 1)

y_pred_max = np.zeros(y_pred.shape)
y_pred_max[np.arange(y_pred.shape[0]), y_pred_class] = 1
~~~

Then you can print the resulting confusion matrix.
~~~
label_names = ['0','1','2','3','4','5','6','7','8','9']
labels = [0,1,2,3,4,5,6,7,8,9]
plot_confusion_matrix(y_test_class, y_pred_class, labels, plot_numbers = True, display_names = label_names)
~~~