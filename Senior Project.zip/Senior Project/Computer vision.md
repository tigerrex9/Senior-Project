Computer vision is a branch of machine learning that deals with image processing, classification, and modification. It's what allows automated vehicles to drive without getting into accidents, face detection, and object detection. It frequently uses [[Types of Layers#Convolution Layers|convolutional layers]].

#TODO expand

## Examples
Autonomous Vehicles (self driving cars)
X-ray, CT, and MRI analysis
Face ID

## Sources 
[31]