Regression models are models that use regression to find a simple function that approximates the relationship between the input features or variables.

Here are some generally accepted variables and what they represent:
$m$: number of training samples
$x$: input variable
$y$: output variable
$x_i$ or $y_i$: the $i$th variable

## Linear
Essentially making a line of best fit. But which line fits the best? We use the Residual Sum of Square (RSS).

## Logistic
Line of best fit but with a logit function

#TODO expand

## Sources
[11]