Layers are the basic building blocks of neural networks in Keras. A layer consists of a tensor-in tensor-out computation function (the layer's call method) and some state, held in TensorFlow variables (the layer's _weights_).

## Core Layers
### Input Object
Input is used to instantiate a Keras tensor.

### Dense Layer
Simplest type of neural network layer. A series of nodes.

### Activation Layer
Applies an [[Activation Functions|activation function]] to an output.

### Embedding Layer
Turns positive integers into dense vectors of fixed size. used as an alternative to one hot encoding.

### Masking Layer
Masks a sequence by using a mask value to skip timesteps.
For each timestep in the input tensor (dimension #1 in the tensor), if all values in the input tensor at that timestep are equal to mask_value, then the timestep will be masked (skipped) in all downstream layers (as long as they support masking). 

### Lambda Layer
Wraps arbitrary expressions as a Layer object.
The Lambda layer exists so that arbitrary expressions can be used as a Layer when constructing Sequential and Functional API models. Lambda layers are best suited for simple operations or quick experimentation.

## Other Layers
### Convolution Layers
This layer creates a convolution kernel that is [[Math Dictionary|convolved]] with the layer input to produce a tensor of outputs.

### Pooling Layers
Downsamples the input along its spatial dimensions by taking the maximum value over an input window for each channel of the input. The window is shifted by strides along each dimension.

### Recurrent Layers
Recurrent networks include the output of the network into its own input.

### Preprocessing Layers
Process an input before feeding it into a network.

### Normalization Layers
Batch normalization applies a transformation that maintains the mean output close to 0 and the output standard deviation close to 1.

### Regularization or Dropout Layers
The Dropout layer randomly sets input units to 0 with a frequency of rate at each step during training time, which helps prevent overfitting. Inputs not set to 0 are scaled up by 1/(1 - rate) such that the sum over all inputs is unchanged.

### Reshaping Layers
Changes the shape of the input to the layer, such as flattening a 2d array into a 1d array.

### Merging Layers
Merges a set of layers using a function such as sum, product, or average.

## Sources
[18]