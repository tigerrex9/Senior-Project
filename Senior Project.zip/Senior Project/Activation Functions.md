These are taken from equations written in the Keras API doc.
## Relu (rectified linear unit)
$$ 
f(x) =
\begin{cases}
0, & x \leq 0 \\
x, & x > 0 \\
\end{cases}
$$
``` desmos-graph
left=-1;right=1;
top=1;bottom=-0.1;
---
f(x)=\{x\le0:0,x>0:x\}
```

## Sigmoid
$$
f(x) = \frac{1}{1+e^{-x}}
$$
``` desmos-graph
left=-10;right=10;
top=1;bottom=-0.1;
---
f(x)=\frac{1}{1+e^{-x}}
```
## Softmax
I'm not touching this shit
## Softplus
$$
f(x) = \log(1+e^x)
$$
``` desmos-graph
left=-2;right=2;
top=3;bottom=-0.1;
---
f(x)=\log{1+e^{x}}
```
## Softsign 
$$
f(x) = \frac{x}{(1+|x|)}
$$
``` desmos-graph
left=-2;right=2;
top=1;bottom=-1;
---
f(x)=\frac{x}{1+\abs(x)}
```
## Hyperbolic Tangent (tanh)
$$
f(x) = \tanh(x)
$$
``` desmos-graph
left=-2;right=2;
top=1;bottom=-1;
---
f(x)=\tanh(x)
```

## Selu (scaled exponential linear unit)
$$
f(a,x) =
\begin{cases}
a(e^x - 1), & x < 0 \\
x, & x \geq 0
\end{cases}
$$
``` desmos-graph
left=-2;right=2;
top=2;bottom=-1;
---
a = 1
f(x)=\{x<0:a(e^{x}-1),x\ge0:x\}
```
## Exponential
$$
f(x) = e^x
$$
``` desmos-graph
left=-2;right=2;
top=3;bottom=-0.1;
---
f(x)=e^{x}
```
## Sources
[19]  [22]