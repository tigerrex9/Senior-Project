## Purpose of a neural network
The purpose of a neural network is solving problems that can't be solved, or are too difficult to solve, through traditional programming. To demonstrate this, I will give an example of a problem that is really hard to solve through programming but is pretty simple for a neural network: data classification. Say I want to make a program that takes in an image of a hand written number *Cough Cough* MNIST *Cough Cough* and outputs the number that was written. That isn't to say that solving this problem without a neural network is impossible, but it is much more difficult than training a neural network to do it.

Most places where you find a problem that you have no idea how you would go about solving you will find a neural network doing the heavy lifting.

## What is a neural network 
It is helpful to think about nodes as neurons and the neural network as a brain. Individually neurons are pretty simple: they have one end that receives electrical signals, and one end that outputs electrical signals, and in the middle you have the bit that decides whether or not to fire. But if you string a bunch of them together, you can make something that is great at pattern recognition.

Most neural networks are made up of [[Types of Layers|layers]], which in turn are typically made up of nodes. Similar to a neuron, each node does a calculation on its inputs to decide its output. 

A node has $n$ inputs: $x_1$, $x_2$, $x_3$... $x_n$. Each input has a trainable weight $w$ that is multiplied with the input and it represents the importance of that input for that node. The node also has an overall bias, $b$, which is added at the end. These are the variables that get tweaked when you train a neural network. 
$$z = \sum_i^n{w_i x_i}+b$$
The node uses the above function and feeds the output $z$ into an [[Activation Functions|activation function]] $f$. $f(z)$ is the final output of the node. If you are having a hard time understanding what this means, here is an explanation of [[Math Dictionary#Sigma Notation|sigma notation]].
The simplest type of layer is a layer that is a set of nodes. This is called a [[Types of Layers#Dense Layer|dense layer]]. Now say that you are trying to solve a more complex problem and an input, an output, and a dense layer, just aren't cutting it. You can string these dense layers together in a chain to make a more complex neural network. Each node from the previous layer is fed as an input into each of the next nodes. 
![[NNGraph.webp]][27]
## How does math learn?
![[machine_learning.png]][23]
[Neural networks learn by seeing what they're supposed to do, seeing what they are currently doing, and calculating the difference between those two states.](https://youtu.be/bZe5J8SVCYQ)[8] How would we quantify the difference between two states with a finite number of data points? I present the cost function. 

### The Cost Function
The cost function, sometimes called the loss function, is a function that takes a set of expected values and a set of returned values and returns a number. The bigger the number, the worse your algorithm. I recommend at this point you try and come up with your own loss function and see how it fares compared to some other solutions people have come up with.

Let's start with the most basic loss function and probably the function that most people would try first, The Sum of Errors(SE), where you take add up the differences  between differences between $Y_i$ and $\hat{Y_i}$ also denoted as $\Delta Y$.
$$L = \sum_{i=1}^n{\hat{Y_i}-Y_i}$$
In the equation above:
$L$ represents the loss
$\hat{Y}$ represents the value that your algorithm returned
$Y$ represents the expected value
$n$ represents the number of data points you have

Now you may have already spotted a problem: positive and negative errors cancel out. Or if your function is bad in a way that makes the returned value much higher or much lower than the expected value an equal amount of the time, the error could end up being much lower than it should be. 

A simple solution to this problem would be taking the absolute difference between $Y$ and $\hat{Y}$ with $$L(Y) = \sum_{i=1}^n{|{\hat{Y_i}-Y_i}|}$$But there is a new problem, this function is not [[Math Dictionary#Derivatives|differentiable]] at 0.  The reason that the activation function being differentiable is so important is so we can do back propagation on the model, as of right now back propagation is outside of the scope of this paper so I recommend watching the video linked below for more information.
https://www.youtube.com/watch?v=tIeHLnjs5U8 [3]

So how can we have a function that inputs two values, and outputs a value that increases as the values get farther apart, and is differentiable at zero? We could use the sum of squared errors. $$L = \sum_{i=1}^n(\hat{Y_i}-Y_i)^2$$This function would end up being differentiable at zero and still has the advantage of increasing with both positive and negative error values. But when we increase the number of data points the loss also increases, ideally this should be the opposite, where with the more data we have the less error we should end up with. Luckily this problem is easily solved resulting in one of the most common loss functions: Mean Squared Error (MSE)[8]$$L = \frac{\sum_{i=1}^n(\hat{Y_i}-Y_i)^2}{n}$$Although there is a problem with MSE, outliers increase the total loss by a lot. $\Delta Y^2$ a lot. 

So far our two best functions are:
$$L = \frac{\sum^{n}_{i=1}{|\hat{Y_i}-{Y_i}|}}{n}$$
$$L = \frac{\sum^{n}_{i=1}{(\hat{Y_i}-{Y_i})^2}}{n}$$
With the former having the issue of not being differentiable at zero and the latter growing exponentially with outliers. What if we could make a function that was $\Delta Y^2$ when $\Delta Y$ was close to 0, and was $|\Delta Y|$ when $\Delta Y$ was further from zero. 
$$ L_\delta(\Delta Y) = 
\begin{cases}
\frac{1}{2}(\Delta Y)^2, & \text{for } |\Delta Y|\leq\delta \\
\delta \cdot (|\Delta Y|-\frac{1}{2}\delta), & \text{otherwise}
\end{cases}$$
It usually looks something like this:
``` desmos-graph
left=-2;right=2;
	top=1.5;bottom=-0.1;
---
f(x)=\{1>x>-1:0.5x^2\}
g(x)=\{-1>x:-x-(1/2)\}
h(x)=\{x>1:x-(1/2)\}
```

Also note the change in $L$. Instead of being the difference between two sets of data it is a function that takes the difference between two data points. To use Huber loss you will have to take the sum of the Huber loss with $$\text{total loss of function} = \frac{\sum^{n}_{i=1}{L_\delta(a_i)}}{n}$$
Now that we have the tools to know how bad our network is, we can use some cool math to figure out how to make it better.

### The Gradient
Forewarning: this is probably the most complex/complicated/confusing part of learning how simple neural networks work. So if you are confused, don't worry. I am too.

Lets say you have a 2 variable function (much more simple than the hundreds or thousands of variables in a decent sized neural network) $f(x,y)$ and you want to find a small value for $f$. Finding the outright minimum of a complicated function can be very difficult, sometimes so difficult that it is considered computationally impossible. So instead of finding the absolute minimum you instead look for a local minimum. To find that you can use something called a gradient. The gradient of a function, denoted as $\nabla f$ is the vector that contains the [[Math Dictionary#Partial Derivatives|partial derivatives]] of the function.
$$\nabla f(x,y)= \begin{bmatrix}
\frac{\partial f}{\partial x} \\ 
\frac{\partial f}{\partial y}
\end{bmatrix}$$
Imagine plotting $f(x,y)$ on a 3 dimensional grid. $\nabla f(x,y)$ would be the direction and magnitude of steepest ascent at that point. To find a local minimum on that function you could find the gradient at your given point and nudge yourself in the opposite direction, picture rolling a ball down a hill. And this works for functions with more variables too, because the gradient vector has components for every variable.

How do we implement something like this? 
### sources
[10]  [12]  [2] 
