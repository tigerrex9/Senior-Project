[1] But what is a neural network? | Chapter 1, Deep learning, (Oct. 05, 2017). Accessed: Dec. 06, 2022. [Online Video]. Available: https://www.youtube.com/watch?v=aircAruvnKk
[2] Gradient descent, how neural networks learn | Chapter 2, Deep learning, (Oct. 16, 2017). Accessed: Dec. 06, 2022. [Online Video]. Available: https://www.youtube.com/watch?v=IHZwWFHWa-w
[3] Backpropagation calculus | Chapter 4, Deep learning, (Nov. 03, 2017). Accessed: Dec. 06, 2022. [Online Video]. Available: https://www.youtube.com/watch?v=tIeHLnjs5U8
[4] What is backpropagation really doing? | Chapter 3, Deep learning, (Nov. 03, 2017). Accessed: Dec. 06, 2022. [Online Video]. Available: https://www.youtube.com/watch?v=Ilg3gGewQ5U
[5] But what is a convolution?, (Nov. 18, 2022). Accessed: Dec. 06, 2022. [Online Video]. Available: https://www.youtube.com/watch?v=KuXjwB4LzSA
[6] IBM, ICLH_Diagram_Batch_01_03-DeepNeuralNetwork-WHITEBG.png (WEBP Image, 1309 × 930 pixels) — Scaled (63%). Accessed: Nov. 29, 2022. [Digital]. Available: https://1.cms.s81c.com/sites/default/files/2021-01-06/ICLH_Diagram_Batch_01_03-DeepNeuralNetwork-WHITEBG.png
[7] The Missile Knows Where It Is..., (Aug. 11, 2012). Accessed: Mar. 09, 2023. [Online Video]. Available: https://www.youtube.com/watch?v=bZe5J8SVCYQ
[8] C. Kathuria, “Regression — Why Mean Square Error?,” Medium, Nov. 15, 2021. https://towardsdatascience.com/https-medium-com-chayankathuria-regression-why-mean-square-error-a8cad2a1c96f (accessed Jan. 16, 2023).
[9] Gradient and graphs, (May 11, 2016). Accessed: Apr. 18, 2023. [Online Video]. Available: https://www.youtube.com/watch?v=_-02ze7tf08
[10] Gradient, (May 23, 2016). Accessed: Apr. 18, 2023. [Online Video]. Available: https://www.youtube.com/watch?v=tIpKfDc295M
[11] D. Krishna, “A Look at the Maths Behind Linear Regression,” Medium, Dec. 16, 2020. https://towardsdatascience.com/a-look-at-the-maths-behind-linear-regression-e9616ca0598 (accessed Dec. 05, 2022).
[12] R. Kwiatkowski, “Gradient Descent Algorithm — a deep dive,” Medium, Jul. 13, 2022. https://towardsdatascience.com/gradient-descent-algorithm-a-deep-dive-cf04e8115f21 (accessed Dec. 08, 2022).
[13] G. D. Luca, “Why Does the Cost Function of Logistic Regression Have a Logarithmic Expression? | Baeldung on Computer Science,” Jul. 23, 2020. https://www.baeldung.com/cs/cost-function-logistic-regression-logarithmic-expr (accessed Dec. 05, 2022).
[14] M. A. Nielsen, “Neural Networks and Deep Learning,” 2015, Accessed: Jan. 09, 2023. [Online]. Available: http://neuralnetworksanddeeplearning.com
[15] K. Rai, “Simple Linear Regression,” Medium, Feb. 05, 2020. https://medium.com/@khushwant.rai78/simple-linear-regression-8225207c4ddc (accessed Dec. 05, 2022).
[16] K. Rai, “The math behind Logistic Regression,” Analytics Vidhya, Jun. 14, 2020. https://medium.com/analytics-vidhya/the-math-behind-logistic-regression-c2f04ca27bca (accessed Dec. 05, 2022).
[17] Building a neural network FROM SCRATCH (no Tensorflow/Pytorch, just numpy & math), (Nov. 24, 2020). Accessed: Dec. 20, 2022. [Online Video]. Available: https://www.youtube.com/watch?v=w8yWXqWQYmU
[18] K. Team, “Keras documentation: Keras layers API.” https://keras.io/api/layers/ (accessed Nov. 17, 2022).
[19] K. Team, “Keras documentation: Layer activation functions.” https://keras.io/api/layers/activations/ (accessed Mar. 13, 2023).
[20] K. Team, “Keras documentation: Simple MNIST convnet.” https://keras.io/examples/vision/mnist_convnet/ (accessed Mar. 07, 2023).
[21] T. Theekshana, “Huber loss: Why is it, like how it is?,” Medium, Jan. 15, 2021. https://www.cantorsparadise.com/huber-loss-why-is-it-like-how-it-is-dcbe47936473 (accessed Jan. 24, 2023).
[22] “Activation Functions in Neural Networks [12 Types & Use Cases].” https://www.v7labs.com/blog/neural-networks-activation-functions, https://www.v7labs.com/blog/neural-networks-activation-functions (accessed Nov. 29, 2022).
[23] “Machine Learning,” xkcd. https://xkcd.com/1838/ (accessed Jan. 09, 2023).
[24] “Node image.” https://assets-global.website-files.com/5d7b77b063a9066d83e1209c/60d2424009416f21db643e21_Group%20807.jpg (accessed Nov. 29, 2022).
[25] “Summation Notation.” http://www.columbia.edu/itc/sipa/math/summation.html (accessed Dec. 05, 2022).
[26] “The Cost Function of Linear Regression: Deep Learning for Beginners | Built In.” https://builtin.com/machine-learning/cost-function (accessed Dec. 08, 2022).
[27] “What are Neural Networks?,” Aug. 03, 2021. https://www.ibm.com/cloud/learn/neural-networks (accessed Nov. 17, 2022).
[28] “What is Natural Language Processing?,” Aug. 16, 2021. https://www.ibm.com/cloud/learn/natural-language-processing (accessed Dec. 08, 2022).
[29] “Huber loss,” Wikipedia. Oct. 06, 2022. Accessed: Dec. 12, 2022. [Online]. Available: https://en.wikipedia.org/w/index.php?title=Huber_loss&oldid=1114469353
[30] “Loss function,” Wikipedia. Nov. 28, 2022. Accessed: Dec. 12, 2022. [Online]. Available: https://en.wikipedia.org/w/index.php?title=Loss_function&oldid=1124243515#Quadratic_loss_function
[31] “Computer vision,” Wikipedia. Feb. 20, 2023. Accessed: Mar. 07, 2023. [Online]. Available: https://en.wikipedia.org/w/index.php?title=Computer_vision&oldid=1140522918
