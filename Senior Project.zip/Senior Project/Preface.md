The purpose of this document is to be an informative and education tool for people interested in how neural networks work, the uses of neural networks, and the underlying math that drives them.

#TODO expand

This Document(s) is intended to be read in order of interest with links to fill in the gaps where needed. Check out the [[Table of Contents]].
