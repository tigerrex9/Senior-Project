Natural language processing is a branch of machine learning that focuses on human language and the ability for computers to understand and interpret  that language.

#TODO expand

## Examples
GPT-3
ChatGPT
Translation Software

## Sources
[28]
