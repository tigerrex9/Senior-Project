This table, like all tables, will have an order. This is not the order that I think you **should** read this document in, but it is an order you could read it in. Also keep in mind that if something has the #TODO tag next to it, that it isn't complete.

## [[Preface]]
## [[Neural Network (NN)]]
## [[Making a Neural Network|Making Neural Networks]]

## [[Math Dictionary]]
## [[Regression Models]]
## [[Computer vision]]
## [[Natural Language Processing]]

## [[Types of Layers]]
## [[Activation Functions]]

## [[Bibliography]]